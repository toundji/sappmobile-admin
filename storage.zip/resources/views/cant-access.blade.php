@extends("admin.base", ['title' => "Impossible d'accéder"])

@section('content')
<div class="col-6 mx-auto fs-5 text-center" style="margin-top: 300px; color: red">
    <i class="uil uil-lock fs-1"></i> <br>

    Vous n'avez pas accès à cette page.
</div>
@endsection
